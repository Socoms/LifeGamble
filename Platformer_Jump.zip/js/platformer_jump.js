// ========================================
// Platformer Jump 게임 JavaScript 코드
// 플랫폼 점프 게임
// ========================================

// ========================================
// Canvas 설정
// ========================================
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// ========================================
// 게임 상태 변수
// ========================================

// 플레이어 설정
let player = {
  x: 180,                    // 플레이어 X 좌표
  y: 500,                    // 플레이어 Y 좌표
  width: 30,                 // 플레이어 너비
  height: 30,                // 플레이어 높이
  xSpeed: 0,                 // 플레이어 X 방향 속도
  ySpeed: 0,                 // ❤️ 플레이어 Y 방향 속도
  jumpPower: -10,            // ❤️ 점프 힘 (음수 = 위쪽)
  gravity: 0.4,              // ❤️ 중력 가속도
  grounded: false            // ❤️ 플레이어가 바닥에 서있는지 여부
};

// 플랫폼 배열
let platforms = [];

// 게임 시간 관리
let startTime = Date.now();  // 게임 시작 시간 (밀리초)
let elapsedTime = 0;         // 경과 시간 (초)

// ========================================
// 키보드 입력 처리
// ========================================
let keys = {};  // 현재 눌려있는 키들을 저장하는 객체

document.addEventListener("keydown", e => keys[e.key] = true);
document.addEventListener("keyup", e => keys[e.key] = false);

// ========================================
// 플랫폼 초기화
// ========================================

// 기본 플랫폼 설정 (플레이어가 시작할 때 서있을 플랫폼)
const startPlatformY = canvas.height - 50;   // 기본 플랫폼 Y 좌표 (화면 하단 근처)
const startPlatformX = 150;                  // 기본 플랫폼 X 좌표
const startPlatformWidth = 100;              // 기본 플랫폼 너비
const startPlatformHeight = 10;              // 기본 플랫폼 높이

// 기본 플랫폼 생성
platforms.push({
  x: startPlatformX,
  y: startPlatformY,
  width: startPlatformWidth,
  height: startPlatformHeight
});

// 플레이어를 기본 플랫폼 위에 배치
player.y = startPlatformY - player.height;

// 랜덤 플랫폼 생성 설정
const platformWidth = 80;                    // 랜덤 플랫폼 너비
const platformHeight = 10;                   // 랜덤 플랫폼 높이
const minDistanceFromStart = 20;             // 기본 플랫폼과의 최소 거리
const maxPlatformY = startPlatformY - minDistanceFromStart - platformHeight;  // 랜덤 플랫폼의 최대 Y 좌표
const minPlatformY = 50;                     // 가장 위쪽 플랫폼의 최소 Y 좌표
const numRandomPlatforms = 6;                // 생성할 랜덤 플랫폼 개수

// 랜덤 플랫폼 생성
for (let i = 0; i < numRandomPlatforms; i++) {
  let x, y;
  
  // Y 좌표 계산: 기본 플랫폼보다 위쪽에만 생성
  const availableYRange = maxPlatformY - minPlatformY;  // 사용 가능한 Y 범위
  const yStep = availableYRange / numRandomPlatforms;   // 플랫폼 간 Y 간격
  
  // 각 플랫폼의 Y 좌표를 고르게 분배
  y = minPlatformY + i * yStep;
  
  // 기본 플랫폼과 Y 좌표가 겹치는지 확인 (안전장치)
  if (y + platformHeight >= startPlatformY) {
    // 겹치면 더 위쪽으로 조정
    y = startPlatformY - minDistanceFromStart - platformHeight - (numRandomPlatforms - i) * 30;
  }
  
  // Y 좌표가 화면 위쪽을 벗어나지 않도록 제한
  if (y < minPlatformY) {
    y = minPlatformY + i * 30;
  }
  
  // X 좌표는 랜덤 생성 (Y 좌표가 다르므로 자유롭게 생성 가능)
  x = Math.random() * (canvas.width - platformWidth);
  
  // 플랫폼 추가
  platforms.push({
    x: x,
    y: y,
    width: platformWidth,
    height: platformHeight
  });
}

// ========================================
// 그리기 함수
// ========================================

// 플레이어 그리기
function drawPlayer() {
  ctx.fillStyle = "blue";
  ctx.fillRect(player.x, player.y, player.width, player.height);
}

// 플랫폼 그리기
function drawPlatforms() {
  ctx.fillStyle = "green";
  platforms.forEach(p => {
    ctx.fillRect(p.x, p.y, p.width, p.height);
  });
}

// 시간 표시
function drawTime() {
  ctx.fillStyle = "black";
  ctx.font = "16px Arial";
  ctx.fillText("Time: " + elapsedTime + "초", 10, 20);
}

// ========================================
// 게임 로직 함수
// ========================================

// 플레이어 이동 처리
function updatePlayerMovement() {
  // 좌우 이동
  if (keys["ArrowLeft"]) player.x -= 3;
  if (keys["ArrowRight"]) player.x += 3;
  
  // ❤️ 중력 적용
  player.ySpeed += player.gravity;
  player.y += player.ySpeed;
  
  // ❤️ 점프 (바닥에 서있을 때만 가능)
  if (player.grounded && keys[" "]) {  // 바닥에 서있고 스페이스바를 누르면 점프
    player.ySpeed = player.jumpPower;
    player.grounded = false;
  }
}

// 플랫폼 충돌 검사 (AABB 충돌 검사)
function checkPlatformCollision() {
  player.grounded = false;
  
  platforms.forEach(p => {
    // AABB 충돌 검사: 두 사각형이 겹치는지 확인
    const isColliding = 
      player.x + player.width > p.x &&           // 플레이어 오른쪽이 플랫폼 왼쪽보다 오른쪽
      player.x < p.x + p.width &&                // 플레이어 왼쪽이 플랫폼 오른쪽보다 왼쪽
      player.y + player.height > p.y &&          // 플레이어 아래쪽이 플랫폼 위쪽보다 아래
      player.y + player.height < p.y + p.height && // 플레이어 아래쪽이 플랫폼 아래쪽보다 위
      player.ySpeed > 0;                         // 플레이어가 아래로 떨어지고 있을 때만
    
    if (isColliding) {
      // ❤️ 플랫폼 위에 서있도록 설정
      player.y = p.y - player.height;
      player.ySpeed = 0;
      player.grounded = true;
    }
  });
}

// 게임 오버 체크
function checkGameOver() {
  // ❤️ 플레이어가 화면 아래로 떨어지면 게임 오버
  if (player.y > canvas.height) {
    alert("Game Over! 생존 시간: " + elapsedTime + "초");
    return true;  // 게임 오버
  }
  return false;  // 게임 계속
}

// ========================================
// 게임 메인 루프
// ========================================
function update() {
  // 화면 지우기
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  // 플레이어 이동 처리
  updatePlayerMovement();
  
  // 플랫폼 충돌 검사
  checkPlatformCollision();
  
  // 경과 시간 계산 (밀리초를 초로 변환, 소수점 1자리)
  elapsedTime = ((Date.now() - startTime) / 1000).toFixed(1);
  
  // 게임 오버 체크
  if (checkGameOver()) {
    return;  // 게임 루프 종료
  }
  
  // 게임 요소 그리기
  drawPlayer();
  drawPlatforms();
  drawTime();
  
  // 다음 프레임 예약 (약 60 FPS)
  requestAnimationFrame(update);
}

// ========================================
// 게임 시작
// ========================================
update();
